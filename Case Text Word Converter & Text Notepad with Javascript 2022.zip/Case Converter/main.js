        let string = document.getElementById('textBox');
        let caseCap = document.getElementById('caseCap');
        let caseUpper = document.getElementById('caseUpper');
        let caseLower = document.getElementById('caseLower');
        
        function UpperCase(){
            textBox.value = textBox.value.toUpperCase()
        }

        function LowerCase(){
            textBox.value = textBox.value.toLowerCase()
        }

        function CapitalizeCase(){
            caseCap.addEventListener('click', () => {
                window.open("capitalFirstLetter.html");
            })
        }

        function nextPage(){
            let textNotepad = document.getElementById('textNotepad');
            textNotepad.addEventListener('click', () => {
                window.open("textNote.html");
            });

        }

         